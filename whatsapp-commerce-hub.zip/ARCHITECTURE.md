# WhatsApp-Commerce Hub — Architecture MVP

## Stack retenue (simple, moderne, adaptée à l'Afrique de l'Ouest)
| Couche | Choix | Pourquoi |
|---|---|---|
| Frontend + Backend | **Next.js (App Router) + React + TypeScript** | Un seul projet : pages publiques SSR ultra-légères + API Routes |
| UI | **Tailwind CSS + Lucide** | Mobile-first, aucun framework lourd ; vitrine < 1,5 Mo |
| Base de données | **PostgreSQL + Drizzle ORM** | Robuste, requêtes typées (remplaçable par Supabase : c'est du Postgres) |
| Auth marchand | Téléphone + mot de passe (scrypt), session cookie httpOnly | Pas d'e-mail obligatoire ; OTP SMS = v2 |
| Commande | **wa.me deep-link** (`src/lib/whatsapp.ts`) | Zéro API WhatsApp Business payante pour le MVP |
| Paiement | À la livraison / Mobile Money négocié sur WhatsApp | Aucune carte bancaire requise |

> Évolution v2 : OTP par SMS/WhatsApp, API WhatsApp Business (Cloud API), Mobile Money
> (Orange Money / Moov Money / MyNita), QR code de boutique, domaine personnalisé.

## Arborescence
```
src/
├── app/
│   ├── page.tsx                     # Landing + boutiques démo + aperçu message WhatsApp
│   ├── connexion/page.tsx           # Login marchand (téléphone)
│   ├── inscription/page.tsx         # Register marchand + création boutique
│   ├── dashboard/page.tsx           # Espace marchand : Aperçu / Produits / Commandes / Boutique
│   ├── boutique/[slug]/
│   │   ├── page.tsx                 # Vitrine publique (SSR, SEO, < 1,5 Mo)
│   │   └── Storefront.tsx           # Panier client (localStorage) + checkout + redirection wa.me
│   └── api/
│       ├── auth/{register,login,logout}/route.ts
│       ├── me/route.ts              # Données du marchand connecté
│       ├── store/route.ts           # PATCH réglages boutique (slug, WhatsApp, ouvert/fermé…)
│       ├── products/route.ts        # POST produit
│       ├── products/[id]/route.ts   # PATCH / DELETE produit
│       ├── orders/[id]/route.ts     # PATCH statut commande
│       └── storefront/[slug]/orders/route.ts  # POST commande publique (prix recalculés serveur)
├── components/AuthForm.tsx
├── lib/
│   ├── whatsapp.ts   # ★ buildWhatsAppOrderLink() : message formaté + encodeURIComponent UTF-8
│   ├── auth.ts       # scrypt, sessions, normalizePhone (+227), slugify
│   └── seed.ts       # Boutiques de démonstration (Chez Awa, Niamey Délices)
└── db/
    ├── index.ts      # Pool PostgreSQL
    └── schema.ts     # merchants, sessions, stores, products, orders
```

## Parcours d'achat
1. Cliente sur `/boutique/[slug]` → panier local (aucun compte).
2. Formulaire : nom, téléphone, quartier de Niamey, point de repère.
3. `POST /api/storefront/[slug]/orders` → commande enregistrée, **prix recalculés en base**.
4. `buildWhatsAppOrderLink()` génère `https://wa.me/227…?text=<message encodé UTF-8>`.
5. WhatsApp s'ouvre chez la cliente → elle appuie sur « Envoyer » → le marchand confirme, livre, encaisse à la livraison.
6. Le marchand suit la commande dans son tableau de bord (En attente → Confirmée → Livrée).

## Compte de démonstration
- Marchand : `+227 96 12 34 56` / `demo1234` → boutique `/boutique/chez-awa-niamey`
- Deuxième vitrine : `/boutique/niamey-delices`
