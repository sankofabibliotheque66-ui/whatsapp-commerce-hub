import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { merchants } from "@/db/schema";
import { createSession, normalizePhone, verifyPassword } from "@/lib/auth";

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const phone = normalizePhone(body?.phone || "");
  const [merchant] = await db.select().from(merchants).where(eq(merchants.phone, phone)).limit(1);
  if (!merchant || !verifyPassword(String(body?.password || ""), merchant.passwordHash)) {
    return NextResponse.json({ error: "Numéro ou mot de passe incorrect." }, { status: 401 });
  }
  await createSession(merchant.id);
  return NextResponse.json({ ok: true });
}
