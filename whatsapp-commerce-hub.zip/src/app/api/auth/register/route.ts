import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { merchants, stores } from "@/db/schema";
import { createSession, hashPassword, normalizePhone, slugify } from "@/lib/auth";
import { normalizeWhatsAppNumber } from "@/lib/whatsapp";

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const phone = normalizePhone(body?.phone || "");
  const password = String(body?.password || "");
  const storeName = String(body?.storeName || "").trim();
  if (phone.length < 9) return NextResponse.json({ error: "Numéro de téléphone invalide. Exemple : 96 12 34 56" }, { status: 400 });
  if (password.length < 6) return NextResponse.json({ error: "Mot de passe : 6 caractères minimum." }, { status: 400 });
  if (storeName.length < 2) return NextResponse.json({ error: "Donnez un nom à votre boutique." }, { status: 400 });

  const [exists] = await db.select().from(merchants).where(eq(merchants.phone, phone)).limit(1);
  if (exists) return NextResponse.json({ error: "Un compte existe déjà avec ce numéro. Connectez-vous." }, { status: 409 });

  // Slug unique : chez-awa, chez-awa-2, chez-awa-3…
  let slug = slugify(storeName); const base = slug; let n = 2;
  while ((await db.select({ id: stores.id }).from(stores).where(eq(stores.slug, slug)).limit(1)).length) slug = `${base}-${n++}`;

  const [merchant] = await db.insert(merchants).values({ phone, passwordHash: hashPassword(password), displayName: String(body?.displayName || "").trim() }).returning();
  const [store] = await db.insert(stores).values({
    merchantId: merchant.id, name: storeName, slug,
    whatsappNumber: normalizeWhatsAppNumber(body?.whatsappNumber || phone),
    description: String(body?.description || "").trim(),
  }).returning();
  await createSession(merchant.id);
  return NextResponse.json({ ok: true, slug: store.slug });
}
