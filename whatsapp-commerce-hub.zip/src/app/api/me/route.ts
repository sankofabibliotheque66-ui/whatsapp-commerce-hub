import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { orders, products } from "@/db/schema";
import { getCurrentMerchant } from "@/lib/auth";

export async function GET() {
  const ctx = await getCurrentMerchant();
  if (!ctx) return NextResponse.json({ error: "Non connecté" }, { status: 401 });
  const prods = await db.select().from(products).where(eq(products.storeId, ctx.store.id)).orderBy(desc(products.createdAt));
  const ords = await db.select().from(orders).where(eq(orders.storeId, ctx.store.id)).orderBy(desc(orders.createdAt)).limit(100);
  return NextResponse.json({
    merchant: { phone: ctx.merchant.phone, displayName: ctx.merchant.displayName },
    store: ctx.store, products: prods, orders: ords,
  });
}
