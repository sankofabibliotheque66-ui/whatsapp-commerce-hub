import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { getCurrentMerchant } from "@/lib/auth";

const STATUSES = ["pending", "confirmed", "delivered", "cancelled"];
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const ctx = await getCurrentMerchant();
  if (!ctx) return NextResponse.json({ error: "Non connecté" }, { status: 401 });
  const { id } = await params;
  const b = await req.json().catch(() => null);
  if (!STATUSES.includes(b?.status)) return NextResponse.json({ error: "Statut invalide" }, { status: 400 });
  const [o] = await db.update(orders).set({ status: b.status })
    .where(and(eq(orders.id, id), eq(orders.storeId, ctx.store.id))).returning();
  if (!o) return NextResponse.json({ error: "Commande introuvable" }, { status: 404 });
  return NextResponse.json({ ok: true, order: o });
}
