import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { getCurrentMerchant } from "@/lib/auth";

async function ownProduct(id: string, storeId: string) {
  const [p] = await db.select().from(products).where(and(eq(products.id, id), eq(products.storeId, storeId))).limit(1);
  return p;
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const ctx = await getCurrentMerchant();
  if (!ctx) return NextResponse.json({ error: "Non connecté" }, { status: 401 });
  const { id } = await params;
  if (!(await ownProduct(id, ctx.store.id))) return NextResponse.json({ error: "Produit introuvable" }, { status: 404 });
  const b = await req.json().catch(() => null);
  const patch: Record<string, unknown> = {};
  if (b.name !== undefined) patch.name = String(b.name).trim();
  if (b.description !== undefined) patch.description = String(b.description).trim();
  if (b.price !== undefined) { const p = Math.round(Number(b.price)); if (!p || p <= 0) return NextResponse.json({ error: "Prix invalide" }, { status: 400 }); patch.price = p; }
  if (b.oldPrice !== undefined) patch.oldPrice = b.oldPrice ? Math.round(Number(b.oldPrice)) || null : null;
  if (b.imageUrl !== undefined) patch.imageUrl = String(b.imageUrl).trim();
  if (b.category !== undefined) patch.category = String(b.category).trim() || "Général";
  if (b.stockStatus !== undefined) patch.stockStatus = b.stockStatus === "out_of_stock" ? "out_of_stock" : "in_stock";
  const [updated] = await db.update(products).set(patch).where(eq(products.id, id)).returning();
  return NextResponse.json({ ok: true, product: updated });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const ctx = await getCurrentMerchant();
  if (!ctx) return NextResponse.json({ error: "Non connecté" }, { status: 401 });
  const { id } = await params;
  if (!(await ownProduct(id, ctx.store.id))) return NextResponse.json({ error: "Produit introuvable" }, { status: 404 });
  await db.delete(products).where(eq(products.id, id));
  return NextResponse.json({ ok: true });
}
