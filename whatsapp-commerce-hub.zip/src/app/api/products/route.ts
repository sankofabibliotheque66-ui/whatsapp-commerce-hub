import { NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { getCurrentMerchant } from "@/lib/auth";

export async function POST(req: Request) {
  const ctx = await getCurrentMerchant();
  if (!ctx) return NextResponse.json({ error: "Non connecté" }, { status: 401 });
  const b = await req.json().catch(() => null);
  const name = String(b?.name || "").trim();
  const price = Math.round(Number(b?.price));
  if (name.length < 2) return NextResponse.json({ error: "Nom du produit requis." }, { status: 400 });
  if (!Number.isFinite(price) || price <= 0) return NextResponse.json({ error: "Prix en FCFA invalide (ex. 2500)." }, { status: 400 });
  const [p] = await db.insert(products).values({
    storeId: ctx.store.id, name,
    description: String(b?.description || "").trim(),
    price, oldPrice: b?.oldPrice ? Math.round(Number(b.oldPrice)) || null : null,
    imageUrl: String(b?.imageUrl || "").trim(),
    category: String(b?.category || "Général").trim() || "Général",
    stockStatus: b?.stockStatus === "out_of_stock" ? "out_of_stock" : "in_stock",
  }).returning();
  return NextResponse.json({ ok: true, product: p });
}
