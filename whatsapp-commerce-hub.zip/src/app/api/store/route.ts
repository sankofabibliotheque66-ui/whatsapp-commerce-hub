import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { stores } from "@/db/schema";
import { getCurrentMerchant, slugify } from "@/lib/auth";
import { normalizeWhatsAppNumber } from "@/lib/whatsapp";

export async function PATCH(req: Request) {
  const ctx = await getCurrentMerchant();
  if (!ctx) return NextResponse.json({ error: "Non connecté" }, { status: 401 });
  const b = await req.json().catch(() => null);
  if (!b) return NextResponse.json({ error: "Données invalides" }, { status: 400 });

  let slug = ctx.store.slug;
  if (b.slug && slugify(b.slug) !== ctx.store.slug) {
    slug = slugify(b.slug);
    const [taken] = await db.select({ id: stores.id }).from(stores).where(eq(stores.slug, slug)).limit(1);
    if (taken) return NextResponse.json({ error: `Le lien « ${slug} » est déjà pris. Choisissez-en un autre.` }, { status: 409 });
  }
  const name = String(b.name || "").trim();
  if (name.length < 2) return NextResponse.json({ error: "Le nom de la boutique est requis." }, { status: 400 });
  const whatsapp = normalizeWhatsAppNumber(b.whatsappNumber || "");
  if (whatsapp.length < 10) return NextResponse.json({ error: "Numéro WhatsApp au format international requis (ex. 227 96 12 34 56)." }, { status: 400 });

  const [updated] = await db.update(stores).set({
    name, slug,
    description: String(b.description || "").trim(),
    logoUrl: String(b.logoUrl || "").trim(),
    whatsappNumber: whatsapp,
    city: String(b.city || "Niamey").trim(),
    neighborhood: String(b.neighborhood || "").trim(),
    deliveryInfo: String(b.deliveryInfo || "").trim(),
    isOpen: Boolean(b.isOpen),
  }).where(eq(stores.id, ctx.store.id)).returning();
  return NextResponse.json({ ok: true, store: updated });
}
