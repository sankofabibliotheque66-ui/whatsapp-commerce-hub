import { NextResponse } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { orders, products, stores } from "@/db/schema";

/**
 * Commande publique (aucun compte client).
 * Les prix sont TOUJOURS recalculés côté serveur depuis la base :
 * on ne fait jamais confiance aux prix envoyés par le navigateur.
 */
export async function POST(req: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [store] = await db.select().from(stores).where(eq(stores.slug, slug)).limit(1);
  if (!store) return NextResponse.json({ error: "Boutique introuvable" }, { status: 404 });
  if (!store.isOpen) return NextResponse.json({ error: "Cette boutique est fermée pour le moment." }, { status: 400 });

  const b = await req.json().catch(() => null);
  const customerName = String(b?.customerName || "").trim();
  const customerPhone = String(b?.customerPhone || "").trim();
  const neighborhood = String(b?.neighborhood || "").trim();
  if (customerName.length < 2) return NextResponse.json({ error: "Votre nom est requis." }, { status: 400 });
  if (customerPhone.replace(/\D/g, "").length < 8) return NextResponse.json({ error: "Numéro de téléphone invalide (8 chiffres minimum)." }, { status: 400 });
  if (neighborhood.length < 2) return NextResponse.json({ error: "Indiquez votre quartier à Niamey." }, { status: 400 });

  const rawItems: { productId: string; quantity: number }[] = Array.isArray(b?.items) ? b.items : [];
  if (!rawItems.length) return NextResponse.json({ error: "Votre panier est vide." }, { status: 400 });

  const ids = [...new Set(rawItems.map((i) => i.productId))];
  const rows = await db.select().from(products).where(inArray(products.id, ids));
  const byId = new Map(rows.filter((p) => p.storeId === store.id).map((p) => [p.id, p]));

  const items = [];
  for (const raw of rawItems) {
    const p = byId.get(raw.productId);
    const qty = Math.max(1, Math.min(99, Math.floor(Number(raw.quantity) || 0)));
    if (!p) return NextResponse.json({ error: "Un produit du panier n'existe plus." }, { status: 400 });
    if (p.stockStatus !== "in_stock") return NextResponse.json({ error: `« ${p.name} » est épuisé.` }, { status: 400 });
    items.push({ productId: p.id, name: p.name, unitPrice: p.price, quantity: qty });
  }
  const total = items.reduce((s, i) => s + i.unitPrice * i.quantity, 0);

  const [order] = await db.insert(orders).values({
    storeId: store.id, customerName, customerPhone, neighborhood,
    landmark: String(b?.landmark || "").trim(), note: String(b?.note || "").trim(),
    items, total,
  }).returning();

  return NextResponse.json({ ok: true, orderId: order.id, total, whatsappNumber: store.whatsappNumber, storeName: store.name });
}
