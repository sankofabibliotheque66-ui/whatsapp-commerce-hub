"use client";
/* ============================================================================
 *  Vitrine publique + panier + redirection WhatsApp
 *  Le panier vit dans le navigateur (localStorage) : aucun compte client.
 *  À la validation : 1) la commande est enregistrée côté serveur (prix
 *  recalculés en base) 2) on ouvre wa.me avec le message formaté.
 * ========================================================================== */
import { useEffect, useMemo, useState } from "react";
import {
  CheckCircle2, ChevronLeft, Eye, Loader2, MapPin, MessageCircle, Minus,
  Package, Plus, Search, Share2, ShoppingBag, Trash2, Truck,
} from "lucide-react";
import type { Product, Store } from "@/db/schema";
import { buildWhatsAppMessage, buildWhatsAppOrderLink, formatFCFA } from "@/lib/whatsapp";

const QUARTIERS_NIAMEY = ["Plateau", "Yantala", "Grand Marché", "Koira Kano", "Bobiel", "Talladjé", "Aéroport", "Saga", "Lamordé", "Goudel", "Foulan Koira", "Autre quartier"];

type Cart = Record<string, number>;

export default function Storefront({ store, products }: { store: Store; products: Product[] }) {
  const [cart, setCart] = useState<Cart>({});
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Tout");
  const [view, setView] = useState<"shop" | "checkout" | "done">("shop");
  const [customer, setCustomer] = useState({ name: "", phone: "", neighborhood: "Plateau", landmark: "", note: "" });
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);
  const [waUrl, setWaUrl] = useState("");
  const [showPreview, setShowPreview] = useState(false);
  const [copied, setCopied] = useState(false);
  const storageKey = `cart-${store.slug}`;

  useEffect(() => {
    try { const raw = localStorage.getItem(storageKey); if (raw) setCart(JSON.parse(raw)); } catch { /* ignore */ }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => { try { localStorage.setItem(storageKey, JSON.stringify(cart)); } catch { /* ignore */ } }, [cart, storageKey]);

  const categories = useMemo(() => ["Tout", ...new Set(products.map((p) => p.category))], [products]);
  const visible = products.filter((p) =>
    (category === "Tout" || p.category === category) &&
    (p.name + " " + p.description).toLowerCase().includes(query.toLowerCase()));
  const cartItems = products.filter((p) => (cart[p.id] || 0) > 0)
    .map((p) => ({ product: p, quantity: cart[p.id], name: p.name, unitPrice: p.price }));
  const total = cartItems.reduce((s, i) => s + i.unitPrice * i.quantity, 0);
  const count = cartItems.reduce((s, i) => s + i.quantity, 0);

  const setQty = (id: string, qty: number) =>
    setCart((c) => { const next = { ...c }; if (qty <= 0) delete next[id]; else next[id] = Math.min(99, qty); return next; });

  const previewMessage = useMemo(() => cartItems.length ? buildWhatsAppMessage({
    storeName: store.name,
    items: cartItems.map((i) => ({ name: i.name, unitPrice: i.unitPrice, quantity: i.quantity })),
    customer: { name: customer.name || "…", phone: customer.phone || "…", neighborhood: customer.neighborhood, landmark: customer.landmark, note: customer.note },
  }) : "", [cartItems, store.name, customer]);

  async function share() {
    const url = window.location.href;
    if (navigator.share) { try { await navigator.share({ title: store.name, text: store.description, url }); return; } catch { /* annulé */ } }
    await navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 2000);
  }

  /** Validation : enregistre la commande puis déclenche le lien wa.me formaté. */
  async function submitOrder(e: React.FormEvent) {
    e.preventDefault(); setError("");
    if (customer.name.trim().length < 2) return setError("Indiquez votre nom.");
    if (customer.phone.replace(/\D/g, "").length < 8) return setError("Numéro invalide : 8 chiffres minimum (ex. 98 11 22 33).");
    if (!cartItems.length) return setError("Votre panier est vide.");
    setSending(true);
    try {
      const res = await fetch(`/api/storefront/${store.slug}/orders`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: customer.name, customerPhone: customer.phone,
          neighborhood: customer.neighborhood, landmark: customer.landmark, note: customer.note,
          items: cartItems.map((i) => ({ productId: i.product.id, quantity: i.quantity })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Impossible d'enregistrer la commande.");

      // ── Génération du lien WhatsApp (voir src/lib/whatsapp.ts) ──
      const url = buildWhatsAppOrderLink({
        merchantWhatsApp: data.whatsappNumber,
        storeName: data.storeName,
        orderRef: `CMD-${data.orderId.slice(0, 8).toUpperCase()}`,
        items: cartItems.map((i) => ({ name: i.name, unitPrice: i.unitPrice, quantity: i.quantity })),
        customer: { name: customer.name, phone: customer.phone, neighborhood: customer.neighborhood, landmark: customer.landmark, note: customer.note },
      });
      setWaUrl(url); setView("done"); setCart({});
      window.open(url, "_blank", "noopener,noreferrer"); // ouverture auto (bouton de secours sur l'écran suivant)
    } catch (err) { setError(err instanceof Error ? err.message : "Erreur réseau, réessayez."); }
    finally { setSending(false); }
  }

  /* ── Écran de confirmation ─────────────────────────────── */
  if (view === "done") {
    return (
      <main className="mx-auto grid min-h-screen w-full max-w-lg place-items-center px-4 py-10">
        <div className="w-full rounded-3xl bg-white p-6 text-center shadow-lg ring-1 ring-black/5 animate-slide-up">
          <CheckCircle2 className="mx-auto h-16 w-16 text-[#128C4A]" />
          <h1 className="mt-3 text-2xl font-black">Commande enregistrée !</h1>
          <p className="mt-2 text-[#14201A]/70">WhatsApp devrait s’ouvrir avec votre commande déjà rédigée. Il ne reste qu’à appuyer sur <strong>Envoyer</strong> dans WhatsApp.</p>
          <a href={waUrl} target="_blank" rel="noopener noreferrer" className="mt-5 flex items-center justify-center gap-2 rounded-full bg-[#25D366] py-4 font-bold text-[#075E54] shadow-lg shadow-[#25D366]/30">
            <MessageCircle className="h-6 w-6" /> Ouvrir WhatsApp et envoyer
          </a>
          <p className="mt-3 text-sm text-[#14201A]/60">Total à payer à la livraison : <strong>{formatFCFA(total)}</strong></p>
          <button onClick={() => setView("shop")} className="mt-4 font-bold text-[#128C4A]">← Continuer mes achats chez {store.name}</button>
        </div>
      </main>
    );
  }

  /* ── Écran panier / livraison ──────────────────────────── */
  if (view === "checkout") {
    return (
      <main className="mx-auto min-h-screen w-full max-w-lg px-4 pb-40 pt-4">
        <button onClick={() => setView("shop")} className="inline-flex items-center gap-1 font-bold text-[#075E54]"><ChevronLeft className="h-5 w-5" /> Retour à la boutique</button>
        <h1 className="mt-3 text-2xl font-black">Finaliser ma commande</h1>

        <section className="mt-4 rounded-3xl bg-white p-4 shadow-sm ring-1 ring-black/5">
          <h2 className="flex items-center gap-2 font-bold"><ShoppingBag className="h-5 w-5 text-[#128C4A]" /> Mon panier ({count})</h2>
          <ul className="mt-3 divide-y divide-black/5">
            {cartItems.map((i) => (
              <li key={i.product.id} className="flex items-center gap-3 py-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                {i.product.imageUrl.startsWith("http") ? <img src={i.product.imageUrl} alt="" className="h-12 w-12 rounded-xl object-cover" loading="lazy" /> : <span className="grid h-12 w-12 place-items-center rounded-xl bg-[#FDF6E9] text-xl">🛍️</span>}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{i.name}</p>
                  <p className="text-sm font-bold text-[#128C4A]">{formatFCFA(i.unitPrice * i.quantity)}</p>
                </div>
                <Qty value={i.quantity} onChange={(q) => setQty(i.product.id, q)} />
              </li>
            ))}
          </ul>
          <div className="mt-2 flex items-center justify-between border-t border-dashed border-black/15 pt-3 text-lg font-black">
            <span>Total (hors livraison)</span><span>{formatFCFA(total)}</span>
          </div>
          <p className="mt-1 text-xs text-[#14201A]/50">{store.deliveryInfo}</p>
        </section>

        <form onSubmit={submitOrder} className="mt-4 rounded-3xl bg-white p-4 shadow-sm ring-1 ring-black/5">
          <h2 className="flex items-center gap-2 font-bold"><Truck className="h-5 w-5 text-[#128C4A]" /> Livraison à {store.city}</h2>
          {error && <p className="mt-3 rounded-xl bg-red-50 px-3 py-2.5 text-sm font-medium text-red-700 ring-1 ring-red-200">{error}</p>}
          <div className="mt-3 space-y-3">
            <label className="block"><span className="mb-1 block text-sm font-semibold">Votre nom *</span>
              <input required className="w-full rounded-xl border border-black/15 px-3.5 py-3 outline-none focus:border-[#128C4A]" placeholder="Ex. Fatima Moussa" value={customer.name} onChange={(e) => setCustomer({ ...customer, name: e.target.value })} /></label>
            <label className="block"><span className="mb-1 block text-sm font-semibold">Votre téléphone (WhatsApp si possible) *</span>
              <input required inputMode="tel" className="w-full rounded-xl border border-black/15 px-3.5 py-3 outline-none focus:border-[#128C4A]" placeholder="Ex. 98 11 22 33" value={customer.phone} onChange={(e) => setCustomer({ ...customer, phone: e.target.value })} /></label>
            <label className="block"><span className="mb-1 block text-sm font-semibold">Quartier à Niamey *</span>
              <select className="w-full rounded-xl border border-black/15 bg-white px-3.5 py-3 outline-none focus:border-[#128C4A]" value={customer.neighborhood} onChange={(e) => setCustomer({ ...customer, neighborhood: e.target.value })}>
                {QUARTIERS_NIAMEY.map((q) => <option key={q}>{q}</option>)}
              </select></label>
            <label className="block"><span className="mb-1 block text-sm font-semibold">Point de repère précis</span>
              <input className="w-full rounded-xl border border-black/15 px-3.5 py-3 outline-none focus:border-[#128C4A]" placeholder="Ex. À côté de la pharmacie, portail vert…" value={customer.landmark} onChange={(e) => setCustomer({ ...customer, landmark: e.target.value })} /></label>
            <label className="block"><span className="mb-1 block text-sm font-semibold">Note pour le marchand (optionnel)</span>
              <textarea rows={2} className="w-full rounded-xl border border-black/15 px-3.5 py-3 outline-none focus:border-[#128C4A]" placeholder="Couleur, pointure, heure de livraison…" value={customer.note} onChange={(e) => setCustomer({ ...customer, note: e.target.value })} /></label>
          </div>

          <button type="button" onClick={() => setShowPreview((s) => !s)} className="mt-4 inline-flex items-center gap-1.5 text-sm font-bold text-[#075E54]">
            <Eye className="h-4 w-4" /> {showPreview ? "Masquer" : "Voir"} le message qui sera envoyé
          </button>
          {showPreview && <pre className="mt-2 whitespace-pre-wrap rounded-2xl bg-[#DCF8C6] p-3.5 text-[13px] leading-relaxed animate-fade-in">{previewMessage}</pre>}

          <button disabled={sending || !cartItems.length} className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-[#25D366] py-4 text-base font-black text-[#075E54] shadow-lg shadow-[#25D366]/30 disabled:opacity-50">
            {sending ? <Loader2 className="h-6 w-6 animate-spin" /> : <MessageCircle className="h-6 w-6" />}
            Valider la commande via WhatsApp
          </button>
          <p className="mt-2 text-center text-xs text-[#14201A]/50">Aucun paiement en ligne : vous payez à la livraison, après confirmation du marchand sur WhatsApp.</p>
        </form>
      </main>
    );
  }

  /* ── Vitrine ───────────────────────────────────────────── */
  return (
    <main className="mx-auto min-h-screen w-full max-w-3xl pb-32">
      <header className="text-white" style={{ background: store.accentColor }}>
        <div className="px-4 pb-5 pt-5">
          <div className="flex items-start gap-3">
            {store.logoUrl.startsWith("http")
              // eslint-disable-next-line @next/next/no-img-element
              ? <img src={store.logoUrl} alt="" className="h-16 w-16 rounded-2xl bg-white/20 object-cover" />
              : <span className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-white/20 text-3xl">{store.logoUrl || store.name.charAt(0)}</span>}
            <div className="min-w-0 flex-1">
              <h1 className="text-2xl font-black leading-tight">{store.name}</h1>
              <p className="mt-0.5 flex items-center gap-1 text-sm text-white/80"><MapPin className="h-4 w-4" /> {store.neighborhood ? `${store.neighborhood}, ` : ""}{store.city} • WhatsApp : +{store.whatsappNumber}</p>
            </div>
            <button onClick={share} className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-white/20" aria-label="Partager la boutique"><Share2 className="h-5 w-5" /></button>
          </div>
          {copied && <p className="mt-2 text-sm font-semibold animate-fade-in">Lien copié ! Partagez-le partout.</p>}
          {store.description && <p className="mt-3 max-w-xl text-sm leading-relaxed text-white/90">{store.description}</p>}
          <p className={`mt-3 inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold ${store.isOpen ? "bg-[#25D366] text-[#075E54]" : "bg-red-500 text-white"}`}>
            {store.isOpen ? "● Boutique ouverte — commandez maintenant" : "● Boutique fermée — réouverture bientôt"}
          </p>
          <p className="mt-3 flex items-start gap-1.5 text-xs text-white/75"><Truck className="mt-0.5 h-4 w-4 shrink-0" /> {store.deliveryInfo}</p>
        </div>
        <div className="px-4 pb-4">
          <label className="relative block">
            <Search className="absolute left-3.5 top-3 h-5 w-5 text-black/35" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Rechercher un produit…" className="w-full rounded-full bg-white py-2.5 pl-11 pr-4 text-[#14201A] outline-none placeholder:text-black/35" />
          </label>
        </div>
      </header>

      {categories.length > 2 && (
        <div className="no-scrollbar sticky top-0 z-30 flex gap-2 overflow-x-auto bg-[#FDF6E9]/95 px-4 py-3 backdrop-blur">
          {categories.map((c) => (
            <button key={c} onClick={() => setCategory(c)} className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-bold ring-1 ${category === c ? "bg-[#075E54] text-white ring-[#075E54]" : "bg-white ring-black/10"}`}>{c}</button>
          ))}
        </div>
      )}

      <section className="grid grid-cols-2 gap-3 px-4 pt-2 sm:grid-cols-3">
        {visible.map((p) => {
          const qty = cart[p.id] || 0; const out = p.stockStatus !== "in_stock";
          return (
            <article key={p.id} className="flex flex-col overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-black/5">
              <div className="relative aspect-square bg-[#F3E7CF]">
                {p.imageUrl.startsWith("http")
                  // eslint-disable-next-line @next/next/no-img-element
                  ? <img src={p.imageUrl} alt={p.name} loading="lazy" className={`h-full w-full object-cover ${out ? "opacity-50 grayscale" : ""}`} />
                  : <span className="grid h-full place-items-center text-5xl">{p.imageUrl || "🛍️"}</span>}
                {out && <span className="absolute left-2 top-2 rounded-full bg-red-600 px-2.5 py-1 text-[11px] font-black text-white">ÉPUISÉ</span>}
                {p.oldPrice && p.oldPrice > p.price && !out && <span className="absolute left-2 top-2 rounded-full bg-[#C2410C] px-2.5 py-1 text-[11px] font-black text-white">-{Math.round((1 - p.price / p.oldPrice) * 100)} %</span>}
              </div>
              <div className="flex flex-1 flex-col p-3">
                <p className="text-[11px] font-bold uppercase tracking-wide text-[#C2410C]">{p.category}</p>
                <h3 className="mt-0.5 line-clamp-2 font-bold leading-snug">{p.name}</h3>
                {p.description && <p className="mt-1 line-clamp-2 text-xs text-[#14201A]/55">{p.description}</p>}
                <div className="mt-auto pt-2">
                  <p className="flex items-baseline gap-1.5">
                    <span className="font-black text-[#128C4A]">{formatFCFA(p.price)}</span>
                    {p.oldPrice && p.oldPrice > p.price && <span className="text-xs text-black/40 line-through">{formatFCFA(p.oldPrice)}</span>}
                  </p>
                  {out ? (
                    <p className="mt-2 rounded-full bg-black/5 py-2 text-center text-sm font-bold text-black/40">Indisponible</p>
                  ) : qty === 0 ? (
                    <button onClick={() => setQty(p.id, 1)} className="mt-2 flex w-full items-center justify-center gap-1 rounded-full bg-[#128C4A] py-2 text-sm font-bold text-white active:scale-[.98]">
                      <Plus className="h-4 w-4" /> Ajouter
                    </button>
                  ) : (
                    <div className="mt-2"><Qty big value={qty} onChange={(q) => setQty(p.id, q)} /></div>
                  )}
                </div>
              </div>
            </article>
          );
        })}
      </section>

      {visible.length === 0 && (
        <div className="px-4 py-16 text-center text-[#14201A]/50">
          <Package className="mx-auto h-10 w-10" />
          <p className="mt-2 font-semibold">Aucun produit trouvé{query && <> pour « {query} »</>}.</p>
        </div>
      )}

      <p className="px-4 pt-8 text-center text-xs text-[#14201A]/40">
        Commande sans compte, paiement à la livraison. Propulsé par WhatsApp-Commerce Hub 🇳🇪
      </p>

      {/* Barre panier fixe (mobile-first) */}
      {count > 0 && (
        <div className="fixed inset-x-0 bottom-0 z-40 px-4 pb-4">
          <button onClick={() => setView("checkout")} className="mx-auto flex w-full max-w-3xl items-center justify-between rounded-full bg-[#075E54] py-3.5 pl-5 pr-2 text-white shadow-2xl animate-slide-up">
            <span className="inline-flex items-center gap-2 font-bold"><ShoppingBag className="h-5 w-5" /> {count} article{count > 1 ? "s" : ""}</span>
            <span className="font-black">{formatFCFA(total)}</span>
            <span className="rounded-full bg-[#25D366] px-4 py-2 font-black text-[#075E54]">Commander →</span>
          </button>
          <button onClick={() => setCart({})} className="mx-auto mt-2 flex items-center gap-1 text-xs font-semibold text-[#14201A]/50"><Trash2 className="h-3.5 w-3.5" /> Vider le panier</button>
        </div>
      )}
    </main>
  );
}

function Qty({ value, onChange, big }: { value: number; onChange: (q: number) => void; big?: boolean }) {
  const btn = `grid place-items-center rounded-full bg-[#075E54] text-white active:scale-95 ${big ? "h-9 w-9" : "h-8 w-8"}`;
  return (
    <div className="flex items-center gap-2">
      <button type="button" className={btn} onClick={() => onChange(value - 1)} aria-label="Diminuer">{value === 1 ? <Trash2 className="h-4 w-4" /> : <Minus className="h-4 w-4" />}</button>
      <span className={`min-w-6 text-center font-black ${big ? "text-lg" : ""}`}>{value}</span>
      <button type="button" className={btn} onClick={() => onChange(value + 1)} aria-label="Augmenter"><Plus className="h-4 w-4" /></button>
    </div>
  );
}
