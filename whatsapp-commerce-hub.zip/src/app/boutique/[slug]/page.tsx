import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { products, stores } from "@/db/schema";
import { ensureSeed } from "@/lib/seed";
import Storefront from "./Storefront";

export const dynamic = "force-dynamic";

async function getStore(slug: string) {
  await ensureSeed();
  const [store] = await db.select().from(stores).where(eq(stores.slug, slug)).limit(1);
  if (!store) return null;
  const prods = await db.select().from(products).where(eq(products.storeId, store.id)).orderBy(asc(products.createdAt));
  return { store, products: prods };
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const data = await getStore(slug).catch(() => null);
  if (!data) return { title: "Boutique introuvable" };
  return {
    title: `${data.store.name} — Commandez sur WhatsApp`,
    description: data.store.description || `Commandez chez ${data.store.name} à ${data.store.city} et payez à la livraison.`,
  };
}

/** Vitrine publique ultra-légère : aucun compte client, HTML servi côté serveur. */
export default async function BoutiquePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const data = await getStore(slug);
  if (!data) notFound();
  return <Storefront store={data.store} products={data.products} />;
}
