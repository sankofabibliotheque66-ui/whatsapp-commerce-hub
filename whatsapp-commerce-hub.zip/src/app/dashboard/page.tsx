"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  Check, Copy, ExternalLink, LayoutDashboard, Loader2, LogOut, MessageCircle,
  Package, Pencil, Plus, Search, Settings, ShoppingBag, Store as StoreIcon, Trash2, X,
} from "lucide-react";
import { formatFCFA, normalizeWhatsAppNumber } from "@/lib/whatsapp";

type Product = { id: string; name: string; description: string; price: number; oldPrice: number | null; imageUrl: string; category: string; stockStatus: string };
type OrderItem = { productId: string; name: string; unitPrice: number; quantity: number };
type Order = { id: string; customerName: string; customerPhone: string; neighborhood: string; landmark: string; note: string; items: OrderItem[]; total: number; status: string; createdAt: string };
type StoreT = { id: string; name: string; slug: string; description: string; logoUrl: string; whatsappNumber: string; city: string; neighborhood: string; deliveryInfo: string; isOpen: boolean; accentColor: string };
type Data = { merchant: { phone: string; displayName: string }; store: StoreT; products: Product[]; orders: Order[] };

const STATUS: Record<string, { label: string; cls: string }> = {
  pending: { label: "En attente", cls: "bg-amber-100 text-amber-800" },
  confirmed: { label: "Confirmée", cls: "bg-sky-100 text-sky-800" },
  delivered: { label: "Livrée", cls: "bg-emerald-100 text-emerald-800" },
  cancelled: { label: "Annulée", cls: "bg-red-100 text-red-700" },
};
const PRESET_IMAGES = [
  ["Pagne / mode", "https://images.pexels.com/photos/38528494/pexels-photo-38528494.jpeg?auto=compress&cs=tinysrgb&w=640"],
  ["Foulard", "https://images.pexels.com/photos/38528500/pexels-photo-38528500.jpeg?auto=compress&cs=tinysrgb&w=640"],
  ["Sac cuir", "https://images.pexels.com/photos/27680730/pexels-photo-27680730.jpeg?auto=compress&cs=tinysrgb&w=640"],
  ["Bijoux", "https://images.pexels.com/photos/1212048/pexels-photo-1212048.jpeg?auto=compress&cs=tinysrgb&w=640"],
  ["Karité / beauté", "https://images.pexels.com/photos/17596984/pexels-photo-17596984.jpeg?auto=compress&cs=tinysrgb&w=640"],
  ["Coffret beauté", "https://images.pexels.com/photos/19522722/pexels-photo-19522722.jpeg?auto=compress&cs=tinysrgb&w=640"],
  ["Chaussures cuir", "https://images.pexels.com/photos/27204307/pexels-photo-27204307.jpeg?auto=compress&cs=tinysrgb&w=640"],
  ["Épices", "https://images.pexels.com/photos/7829483/pexels-photo-7829483.jpeg?auto=compress&cs=tinysrgb&w=640"],
  ["Piment", "https://images.pexels.com/photos/38882159/pexels-photo-38882159.jpeg?auto=compress&cs=tinysrgb&w=640"],
] as const;

const inputCls = "w-full rounded-xl border border-black/15 bg-white px-3.5 py-2.5 outline-none focus:border-[#128C4A] focus:ring-2 focus:ring-[#25D366]/30";

export default function DashboardPage() {
  const router = useRouter();
  const [data, setData] = useState<Data | null>(null);
  const [tab, setTab] = useState<"overview" | "products" | "orders" | "settings">("overview");
  const [toast, setToast] = useState("");

  const load = useCallback(async () => {
    const res = await fetch("/api/me");
    if (res.status === 401) { router.push("/connexion"); return; }
    setData(await res.json());
  }, [router]);
  useEffect(() => { load(); }, [load]);

  function notify(msg: string) { setToast(msg); setTimeout(() => setToast(""), 2600); }
  async function logout() { await fetch("/api/auth/logout", { method: "POST" }); router.push("/"); router.refresh(); }

  const stats = useMemo(() => {
    if (!data) return { revenue: 0, pending: 0, orders: 0, products: 0 };
    return {
      revenue: data.orders.filter((o) => o.status === "delivered").reduce((s, o) => s + o.total, 0),
      pending: data.orders.filter((o) => o.status === "pending").length,
      orders: data.orders.length,
      products: data.products.filter((p) => p.stockStatus === "in_stock").length,
    };
  }, [data]);

  if (!data) return <main className="grid min-h-screen place-items-center"><Loader2 className="h-8 w-8 animate-spin text-[#128C4A]" /></main>;
  const storeUrl = `/boutique/${data.store.slug}`;

  return (
    <main className="min-h-screen">
      <header className="sticky top-0 z-40 bg-[#075E54] text-white shadow">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/15 text-xl">{data.store.logoUrl && !data.store.logoUrl.startsWith("http") ? data.store.logoUrl : <StoreIcon className="h-5 w-5" />}</span>
          <div className="min-w-0 flex-1">
            <p className="truncate font-black leading-tight">{data.store.name}</p>
            <p className="text-xs text-white/70">{data.merchant.phone} • {data.store.isOpen ? "Boutique ouverte" : "Boutique fermée"}</p>
          </div>
          <Link href={storeUrl} className="hidden items-center gap-1.5 rounded-full bg-[#25D366] px-4 py-2 text-sm font-bold text-[#075E54] sm:inline-flex"><ExternalLink className="h-4 w-4" /> Ma vitrine</Link>
          <button onClick={logout} className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-2 text-sm font-semibold"><LogOut className="h-4 w-4" /> <span className="hidden sm:inline">Déconnexion</span></button>
        </div>
        <nav className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 pb-3">
          {([["overview", LayoutDashboard, "Aperçu"], ["products", Package, `Produits (${data.products.length})`], ["orders", ShoppingBag, `Commandes${stats.pending ? ` • ${stats.pending}` : ""}`], ["settings", Settings, "Boutique"]] as const).map(([key, Icon, label]) => (
            <button key={key} onClick={() => setTab(key)} className={`inline-flex whitespace-nowrap items-center gap-1.5 rounded-full px-4 py-2 text-sm font-bold ${tab === key ? "bg-white text-[#075E54]" : "bg-white/10 text-white"}`}>
              <Icon className="h-4 w-4" /> {label}
            </button>
          ))}
        </nav>
      </header>

      <div className="mx-auto max-w-6xl px-4 py-6">
        {tab === "overview" && <Overview data={data} stats={stats} storeUrl={storeUrl} notify={notify} goOrders={() => setTab("orders")} />}
        {tab === "products" && <ProductsTab products={data.products} reload={load} notify={notify} />}
        {tab === "orders" && <OrdersTab orders={data.orders} reload={load} notify={notify} />}
        {tab === "settings" && <SettingsTab store={data.store} reload={load} notify={notify} />}
      </div>

      {toast && <div className="fixed bottom-5 left-1/2 z-50 -translate-x-1/2 rounded-full bg-[#14201A] px-5 py-3 font-semibold text-white shadow-xl animate-slide-up"><Check className="mr-1 inline h-4 w-4 text-[#25D366]" />{toast}</div>}
    </main>
  );
}

/* ───────────────────────── Aperçu ───────────────────────── */
function Overview({ data, stats, storeUrl, notify, goOrders }: { data: Data; stats: { revenue: number; pending: number; orders: number; products: number }; storeUrl: string; notify: (m: string) => void; goOrders: () => void }) {
  const fullUrl = typeof window !== "undefined" ? `${window.location.origin}${storeUrl}` : storeUrl;
  async function copy() { await navigator.clipboard.writeText(fullUrl); notify("Lien de votre boutique copié !"); }
  async function share() {
    if (navigator.share) { try { await navigator.share({ title: data.store.name, text: `Commandez chez ${data.store.name} — paiement à la livraison`, url: fullUrl }); return; } catch { /* ignore */ } }
    copy();
  }
  return (
    <div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          ["Chiffre d’affaires (livré)", formatFCFA(stats.revenue), "💰"],
          ["Commandes en attente", String(stats.pending), "⏳"],
          ["Commandes totales", String(stats.orders), "🧾"],
          ["Produits en stock", String(stats.products), "📦"],
        ].map(([label, value, icon]) => (
          <div key={label} className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-black/5">
            <p className="text-2xl">{icon}</p><p className="mt-1 text-2xl font-black">{value}</p><p className="text-sm text-[#14201A]/55">{label}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-3xl bg-[#075E54] p-5 text-white">
        <h2 className="flex items-center gap-2 text-lg font-black"><MessageCircle className="h-5 w-5 text-[#25D366]" /> Votre lien de vente unique</h2>
        <p className="mt-1 text-sm text-white/75">Partagez-le dans vos statuts WhatsApp, groupes, Facebook ou sur un QR code en boutique. Vos clientes commandent sans compte.</p>
        <div className="mt-3 flex flex-col gap-2 sm:flex-row">
          <code className="flex-1 truncate rounded-xl bg-white/10 px-4 py-3 text-sm">{fullUrl}</code>
          <button onClick={copy} className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-white px-4 py-3 font-bold text-[#075E54]"><Copy className="h-4 w-4" /> Copier</button>
          <button onClick={share} className="rounded-xl bg-[#25D366] px-4 py-3 font-bold text-[#075E54]">Partager</button>
          <Link href={storeUrl} className="rounded-xl bg-white/15 px-4 py-3 text-center font-bold">Ouvrir →</Link>
        </div>
      </div>

      <div className="mt-4 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-black/5">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-black">Dernières commandes</h2>
          <button onClick={goOrders} className="font-bold text-[#128C4A]">Tout voir →</button>
        </div>
        {data.orders.length === 0 ? <p className="mt-3 text-[#14201A]/55">Aucune commande pour l’instant. Partagez votre lien pour recevoir la première !</p> : (
          <ul className="mt-2 divide-y divide-black/5">
            {data.orders.slice(0, 5).map((o) => (
              <li key={o.id} className="flex flex-wrap items-center gap-2 py-3">
                <div className="min-w-0 flex-1">
                  <p className="font-bold">{o.customerName} <span className="font-normal text-[#14201A]/50">• {o.neighborhood}</span></p>
                  <p className="text-sm text-[#14201A]/55">{o.items.reduce((s, i) => s + i.quantity, 0)} article(s) • {new Date(o.createdAt).toLocaleString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</p>
                </div>
                <span className="font-black">{formatFCFA(o.total)}</span>
                <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${STATUS[o.status]?.cls}`}>{STATUS[o.status]?.label}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

/* ───────────────────────── Produits ───────────────────────── */
function ProductsTab({ products, reload, notify }: { products: Product[]; reload: () => Promise<void>; notify: (m: string) => void }) {
  const empty = { name: "", description: "", price: "", oldPrice: "", imageUrl: "", category: "Général", stockStatus: "in_stock" };
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);

  async function save(e: React.FormEvent) {
    e.preventDefault(); setBusy(true);
    const payload = { ...form, price: Number(form.price), oldPrice: form.oldPrice ? Number(form.oldPrice) : null };
    const res = await fetch(editing ? `/api/products/${editing}` : "/api/products", {
      method: editing ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    const d = await res.json(); setBusy(false);
    if (!res.ok) return notify(d.error || "Erreur");
    notify(editing ? "Produit modifié" : "Produit ajouté à votre vitrine");
    setForm(empty); setEditing(null); setShowForm(false); reload();
  }
  async function toggle(p: Product) {
    await fetch(`/api/products/${p.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ stockStatus: p.stockStatus === "in_stock" ? "out_of_stock" : "in_stock" }) });
    notify(p.stockStatus === "in_stock" ? "Marqué épuisé" : "Remis en stock"); reload();
  }
  async function remove(p: Product) {
    if (!confirm(`Supprimer définitivement « ${p.name} » ?`)) return;
    await fetch(`/api/products/${p.id}`, { method: "DELETE" }); notify("Produit supprimé"); reload();
  }
  const visible = products.filter((p) => (p.name + p.category).toLowerCase().includes(query.toLowerCase()));

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2">
        <label className="relative min-w-52 flex-1">
          <Search className="absolute left-3 top-3 h-5 w-5 text-black/30" />
          <input className={`${inputCls} pl-10`} placeholder="Rechercher un produit…" value={query} onChange={(e) => setQuery(e.target.value)} />
        </label>
        <button onClick={() => { setForm(empty); setEditing(null); setShowForm((s) => !s); }} className="inline-flex items-center gap-1.5 rounded-full bg-[#128C4A] px-5 py-2.5 font-bold text-white">
          {showForm ? <X className="h-5 w-5" /> : <Plus className="h-5 w-5" />} {showForm ? "Fermer" : "Ajouter un produit"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={save} className="mt-4 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-black/5 animate-slide-up">
          <h2 className="text-lg font-black">{editing ? "Modifier le produit" : "Nouveau produit"}</h2>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <label className="sm:col-span-2"><span className="mb-1 block text-sm font-semibold">Nom *</span><input required className={inputCls} placeholder="Ex. Pagne wax premium — 6 yards" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label>
            <label><span className="mb-1 block text-sm font-semibold">Prix (FCFA) *</span><input required type="number" min={1} className={inputCls} placeholder="8500" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} /></label>
            <label><span className="mb-1 block text-sm font-semibold">Ancien prix barré (optionnel)</span><input type="number" min={0} className={inputCls} placeholder="10000" value={form.oldPrice} onChange={(e) => setForm({ ...form, oldPrice: e.target.value })} /></label>
            <label><span className="mb-1 block text-sm font-semibold">Catégorie</span><input className={inputCls} placeholder="Ex. Pagnes & tissus" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} /></label>
            <label><span className="mb-1 block text-sm font-semibold">Stock</span>
              <select className={inputCls} value={form.stockStatus} onChange={(e) => setForm({ ...form, stockStatus: e.target.value })}>
                <option value="in_stock">✅ En stock</option><option value="out_of_stock">❌ Épuisé</option>
              </select></label>
            <label className="sm:col-span-2"><span className="mb-1 block text-sm font-semibold">Description</span><textarea rows={2} className={inputCls} placeholder="Matière, tailles, couleurs, conseils…" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></label>
            <label className="sm:col-span-2"><span className="mb-1 block text-sm font-semibold">Image : URL, emoji, ou choisissez ci-dessous</span><input className={inputCls} placeholder="https://… ou 📦" value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} /></label>
          </div>
          <div className="no-scrollbar mt-2 flex gap-2 overflow-x-auto pb-1">
            {PRESET_IMAGES.map(([label, url]) => (
              <button type="button" key={url} onClick={() => setForm({ ...form, imageUrl: url })} className={`relative shrink-0 overflow-hidden rounded-xl ring-2 ${form.imageUrl === url ? "ring-[#128C4A]" : "ring-transparent"}`}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={url} alt={label} className="h-16 w-16 object-cover" loading="lazy" /><span className="absolute inset-x-0 bottom-0 bg-black/55 px-1 text-[10px] font-semibold text-white">{label}</span>
              </button>
            ))}
          </div>
          {form.imageUrl.startsWith("http") && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={form.imageUrl} alt="Aperçu" className="mt-3 h-32 w-32 rounded-2xl object-cover" />
          )}
          <button disabled={busy} className="mt-4 rounded-full bg-[#128C4A] px-6 py-3 font-bold text-white disabled:opacity-60">{busy ? "Enregistrement…" : editing ? "Enregistrer les modifications" : "Ajouter à ma vitrine"}</button>
        </form>
      )}

      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {visible.map((p) => (
          <article key={p.id} className="flex gap-3 rounded-3xl bg-white p-3 shadow-sm ring-1 ring-black/5">
            {p.imageUrl.startsWith("http")
              // eslint-disable-next-line @next/next/no-img-element
              ? <img src={p.imageUrl} alt="" className="h-24 w-24 shrink-0 rounded-2xl object-cover" loading="lazy" />
              : <span className="grid h-24 w-24 shrink-0 place-items-center rounded-2xl bg-[#FDF6E9] text-4xl">{p.imageUrl || "🛍️"}</span>}
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-bold uppercase tracking-wide text-[#C2410C]">{p.category}</p>
              <h3 className="line-clamp-2 font-bold leading-snug">{p.name}</h3>
              <p className="mt-0.5 font-black text-[#128C4A]">{formatFCFA(p.price)} {p.oldPrice && <span className="text-xs font-normal text-black/40 line-through">{formatFCFA(p.oldPrice)}</span>}</p>
              <span className={`mt-1 inline-block rounded-full px-2 py-0.5 text-[11px] font-bold ${p.stockStatus === "in_stock" ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-700"}`}>{p.stockStatus === "in_stock" ? "En stock" : "Épuisé"}</span>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <button onClick={() => { setEditing(p.id); setForm({ name: p.name, description: p.description, price: String(p.price), oldPrice: p.oldPrice ? String(p.oldPrice) : "", imageUrl: p.imageUrl, category: p.category, stockStatus: p.stockStatus }); setShowForm(true); }} className="inline-flex items-center gap-1 rounded-full bg-black/5 px-2.5 py-1.5 text-xs font-bold"><Pencil className="h-3.5 w-3.5" /> Modifier</button>
                <button onClick={() => toggle(p)} className="rounded-full bg-black/5 px-2.5 py-1.5 text-xs font-bold">{p.stockStatus === "in_stock" ? "Marquer épuisé" : "Remettre en stock"}</button>
                <button onClick={() => remove(p)} className="inline-flex items-center gap-1 rounded-full bg-red-50 px-2.5 py-1.5 text-xs font-bold text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </div>
          </article>
        ))}
      </div>
      {visible.length === 0 && <p className="py-14 text-center text-[#14201A]/50">Aucun produit. Cliquez sur « Ajouter un produit » pour commencer à vendre.</p>}
    </div>
  );
}

/* ───────────────────────── Commandes ───────────────────────── */
function OrdersTab({ orders, reload, notify }: { orders: Order[]; reload: () => Promise<void>; notify: (m: string) => void }) {
  const [filter, setFilter] = useState("all");
  const [open, setOpen] = useState<string | null>(null);
  async function setStatus(o: Order, status: string) {
    await fetch(`/api/orders/${o.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) });
    notify(`Commande marquée « ${STATUS[status].label} »`); reload();
  }
  const visible = orders.filter((o) => filter === "all" || o.status === filter);
  return (
    <div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
        {[["all", "Toutes"], ...Object.entries(STATUS).map(([k, v]) => [k, v.label] as [string, string])].map(([k, label]) => (
          <button key={k} onClick={() => setFilter(k)} className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-bold ring-1 ${filter === k ? "bg-[#075E54] text-white ring-[#075E54]" : "bg-white ring-black/10"}`}>
            {label} {k !== "all" && `(${orders.filter((o) => o.status === k).length})`}
          </button>
        ))}
      </div>
      <div className="mt-3 space-y-3">
        {visible.map((o) => (
          <article key={o.id} className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-black/5">
            <button className="flex w-full flex-wrap items-center gap-2 text-left" onClick={() => setOpen(open === o.id ? null : o.id)}>
              <div className="min-w-0 flex-1">
                <p className="font-black">{o.customerName} <span className="text-sm font-medium text-[#14201A]/50">• {o.customerPhone}</span></p>
                <p className="text-sm text-[#14201A]/55">📍 {o.neighborhood}{o.landmark ? ` — ${o.landmark}` : ""} • {new Date(o.createdAt).toLocaleString("fr-FR")}</p>
              </div>
              <span className="font-black">{formatFCFA(o.total)}</span>
              <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${STATUS[o.status]?.cls}`}>{STATUS[o.status]?.label}</span>
            </button>
            {open === o.id && (
              <div className="mt-3 border-t border-dashed border-black/10 pt-3 animate-fade-in">
                <ul className="space-y-1 text-sm">
                  {o.items.map((i, idx) => <li key={idx} className="flex justify-between gap-3"><span>{i.quantity} × {i.name}</span><strong>{formatFCFA(i.unitPrice * i.quantity)}</strong></li>)}
                </ul>
                {o.note && <p className="mt-2 rounded-xl bg-[#FDF6E9] px-3 py-2 text-sm">📝 {o.note}</p>}
                <div className="mt-3 flex flex-wrap gap-2">
                  <a href={`https://wa.me/${normalizeWhatsAppNumber(o.customerPhone)}?text=${encodeURIComponent(`Bonjour ${o.customerName}, ici commande de ${formatFCFA(o.total)} : je vous confirme…`)}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 rounded-full bg-[#25D366] px-4 py-2 text-sm font-bold text-[#075E54]"><MessageCircle className="h-4 w-4" /> Répondre sur WhatsApp</a>
                  {Object.entries(STATUS).filter(([k]) => k !== o.status).map(([k, v]) => (
                    <button key={k} onClick={() => setStatus(o, k)} className="rounded-full bg-black/5 px-3.5 py-2 text-sm font-bold">Marquer {v.label.toLowerCase()}</button>
                  ))}
                </div>
              </div>
            )}
          </article>
        ))}
        {visible.length === 0 && <p className="py-14 text-center text-[#14201A]/50">Aucune commande dans cette catégorie pour le moment.</p>}
      </div>
    </div>
  );
}

/* ───────────────────────── Réglages boutique ───────────────────────── */
function SettingsTab({ store, reload, notify }: { store: StoreT; reload: () => Promise<void>; notify: (m: string) => void }) {
  const [form, setForm] = useState({ ...store });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function save(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    const res = await fetch("/api/store", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const d = await res.json(); setBusy(false);
    if (!res.ok) return setError(d.error || "Erreur");
    notify("Boutique mise à jour"); reload();
  }
  return (
    <form onSubmit={save} className="max-w-2xl rounded-3xl bg-white p-5 shadow-sm ring-1 ring-black/5">
      <h2 className="text-lg font-black">Ma boutique</h2>
      {error && <p className="mt-3 rounded-xl bg-red-50 px-3 py-2.5 text-sm font-medium text-red-700 ring-1 ring-red-200">{error}</p>}
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <label className="sm:col-span-2"><span className="mb-1 block text-sm font-semibold">Nom de la boutique *</span><input required className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label>
        <label><span className="mb-1 block text-sm font-semibold">Lien unique (slug) *</span>
          <span className="flex items-center gap-1"><span className="text-sm text-black/40">/boutique/</span><input className={inputCls} value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} /></span></label>
        <label><span className="mb-1 block text-sm font-semibold">Numéro WhatsApp (international) *</span><input className={inputCls} placeholder="22796123456" value={form.whatsappNumber} onChange={(e) => setForm({ ...form, whatsappNumber: e.target.value })} />
          <span className="mt-1 block text-xs text-black/45">C’est sur ce numéro que vous recevrez les commandes.</span></label>
        <label><span className="mb-1 block text-sm font-semibold">Logo : emoji ou URL d’image</span><input className={inputCls} placeholder="🛍️ ou https://…" value={form.logoUrl} onChange={(e) => setForm({ ...form, logoUrl: e.target.value })} /></label>
        <label><span className="mb-1 block text-sm font-semibold">Couleur de la vitrine</span><input type="color" className="h-11 w-full rounded-xl border border-black/15 bg-white px-2" value={form.accentColor} onChange={(e) => setForm({ ...form, accentColor: e.target.value })} /></label>
        <label><span className="mb-1 block text-sm font-semibold">Ville</span><input className={inputCls} value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></label>
        <label><span className="mb-1 block text-sm font-semibold">Quartier de la boutique</span><input className={inputCls} placeholder="Ex. Grand Marché" value={form.neighborhood} onChange={(e) => setForm({ ...form, neighborhood: e.target.value })} /></label>
        <label className="sm:col-span-2"><span className="mb-1 block text-sm font-semibold">Description</span><textarea rows={3} className={inputCls} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></label>
        <label className="sm:col-span-2"><span className="mb-1 block text-sm font-semibold">Infos livraison & paiement</span><textarea rows={2} className={inputCls} value={form.deliveryInfo} onChange={(e) => setForm({ ...form, deliveryInfo: e.target.value })} /></label>
      </div>
      <label className="mt-4 flex cursor-pointer items-center gap-3 rounded-2xl bg-[#FDF6E9] px-4 py-3">
        <input type="checkbox" className="h-5 w-5 accent-[#128C4A]" checked={form.isOpen} onChange={(e) => setForm({ ...form, isOpen: e.target.checked })} />
        <span><strong>Boutique ouverte</strong><span className="block text-sm text-black/55">Décochez pendant vos congés : la vitrine reste visible mais les commandes sont bloquées.</span></span>
      </label>
      {/* aperçu couleur */}
      <div className="mt-4 overflow-hidden rounded-2xl text-white" style={{ background: form.accentColor }}>
        <div className="p-4"><p className="font-black">{form.name || "Votre boutique"}</p><p className="text-sm text-white/80">Aperçu de l’en-tête de votre vitrine</p></div>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <button disabled={busy} className="rounded-full bg-[#128C4A] px-6 py-3 font-bold text-white disabled:opacity-60">{busy ? "Enregistrement…" : "Enregistrer ma boutique"}</button>
        <Link href={`/boutique/${form.slug}`} className="rounded-full bg-black/5 px-6 py-3 font-bold">Voir ma vitrine →</Link>
      </div>
    </form>
  );
}
