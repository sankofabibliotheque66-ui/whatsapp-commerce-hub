import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "WhatsApp-Commerce Hub — Vendez sur WhatsApp, sans site e-commerce compliqué",
  description: "Créez votre mini-vitrine en ligne au Niger, recevez des commandes structurées directement sur WhatsApp. Aucune carte bancaire requise, paiement à la livraison.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#075E54" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <body className="bg-[#FDF6E9] text-[#14201A] antialiased">{children}</body>
    </html>
  );
}
