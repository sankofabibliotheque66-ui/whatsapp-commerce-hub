import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { products, stores } from "@/db/schema";
import { ensureSeed } from "@/lib/seed";
import { buildWhatsAppMessage, formatFCFA } from "@/lib/whatsapp";
import {
  ArrowRight, BadgeCheck, Banknote, ClipboardList, Link2, MessageCircle,
  Package, Phone, Share2, ShoppingBag, Smartphone, Store, Truck,
} from "lucide-react";

export const dynamic = "force-dynamic";

const QUARTIERS = ["Plateau", "Yantala", "Grand Marché", "Koira Kano", "Bobiel", "Talladjé", "Aéroport", "Saga", "Lamordé", "Goudel"];

export default async function HomePage() {
  await ensureSeed();
  const allStores = await db.select().from(stores).orderBy(desc(stores.createdAt));
  const allProducts = await db.select().from(products);
  const countByStore = new Map<string, number>();
  allProducts.forEach((p) => countByStore.set(p.storeId, (countByStore.get(p.storeId) || 0) + 1));

  const demoMessage = buildWhatsAppMessage({
    storeName: "Chez Awa — Pagnes & Beauté",
    orderRef: "CMD-2026-0142",
    items: [
      { name: "Pagne wax premium — 6 yards", unitPrice: 8500, quantity: 2 },
      { name: "Beurre de karité pur — 250 g", unitPrice: 2500, quantity: 1 },
    ],
    customer: { name: "Fatima Moussa", phone: "98 11 22 33", neighborhood: "Plateau", landmark: "À côté de la pharmacie du Plateau" },
  });

  return (
    <main className="min-h-screen">
      {/* ── Header ─────────────────────────────────────────── */}
      <header className="sticky top-0 z-40 border-b border-[#14201A]/10 bg-[#FDF6E9]/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <Link href="/" className="flex items-center gap-2 font-black text-lg">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#075E54] text-white"><MessageCircle className="h-5 w-5" /></span>
            <span>WhatsApp<span className="text-[#128C4A]">-Commerce</span> Hub</span>
          </Link>
          <nav className="flex items-center gap-2 text-sm font-semibold">
            <Link href="/boutique/chez-awa-niamey" className="hidden rounded-full px-3 py-2 hover:bg-black/5 sm:block">Voir une vitrine</Link>
            <Link href="/connexion" className="rounded-full px-3 py-2 hover:bg-black/5">Connexion</Link>
            <Link href="/inscription" className="rounded-full bg-[#128C4A] px-4 py-2 text-white shadow hover:bg-[#0F7A3E]">Créer ma boutique</Link>
          </nav>
        </div>
      </header>

      {/* ── Hero ───────────────────────────────────────────── */}
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 pb-14 pt-10 lg:grid-cols-2 lg:pt-16">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full bg-[#075E54] px-3 py-1 text-xs font-bold uppercase tracking-wide text-white">
            <Smartphone className="h-3.5 w-3.5" /> Pensé pour Niamey & l’Afrique de l’Ouest
          </p>
          <h1 className="mt-5 text-4xl font-black leading-[1.05] sm:text-5xl">
            Vendez sur WhatsApp,<br />sans site e-commerce <span className="text-[#128C4A]">compliqué</span>.
          </h1>
          <p className="mt-4 max-w-lg text-lg text-[#14201A]/70">
            Créez votre mini-vitrine en 5 minutes, partagez votre lien unique, et recevez des commandes
            <strong> structurées directement dans votre WhatsApp</strong> : articles, quantités, total en FCFA
            et adresse de livraison à Niamey. Aucune carte bancaire — paiement à la livraison.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/inscription" className="inline-flex items-center gap-2 rounded-full bg-[#25D366] px-6 py-3.5 font-bold text-[#075E54] shadow-lg shadow-[#25D366]/30 hover:brightness-95">
              Créer ma boutique gratuite <ArrowRight className="h-5 w-5" />
            </Link>
            <Link href="/boutique/chez-awa-niamey" className="inline-flex items-center gap-2 rounded-full border-2 border-[#075E54] px-6 py-3.5 font-bold text-[#075E54] hover:bg-[#075E54] hover:text-white">
              <ShoppingBag className="h-5 w-5" /> Essayer comme cliente
            </Link>
          </div>
          <div className="mt-6 flex flex-wrap gap-x-5 gap-y-2 text-sm font-medium text-[#14201A]/70">
            <span className="inline-flex items-center gap-1.5"><BadgeCheck className="h-4 w-4 text-[#128C4A]" /> Sans carte bancaire</span>
            <span className="inline-flex items-center gap-1.5"><Banknote className="h-4 w-4 text-[#128C4A]" /> Paiement à la livraison</span>
            <span className="inline-flex items-center gap-1.5"><Smartphone className="h-4 w-4 text-[#128C4A]" /> Vitrine &lt; 1,5 Mo, 2G/3G OK</span>
          </div>
          <div className="mt-8 grid max-w-md grid-cols-3 gap-3 text-center">
            {[["5 min", "pour ouvrir"], ["0 FCFA", "pour démarrer"], ["100 %", "via WhatsApp"]].map(([v, l]) => (
              <div key={l} className="rounded-2xl bg-white p-3 shadow-sm ring-1 ring-black/5">
                <p className="text-xl font-black text-[#075E54]">{v}</p><p className="text-xs text-[#14201A]/60">{l}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Aperçu du message WhatsApp généré automatiquement */}
        <div className="mx-auto w-full max-w-md">
          <div className="overflow-hidden rounded-[2rem] bg-[#0B141A] shadow-2xl ring-8 ring-[#0B141A]">
            <div className="flex items-center gap-3 bg-[#075E54] px-4 py-3 text-white">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-[#25D366] text-lg font-black text-[#075E54]">A</span>
              <div className="min-w-0">
                <p className="truncate font-bold">Chez Awa — Pagnes & Beauté</p>
                <p className="text-xs text-white/70">en ligne • +227 96 12 34 56</p>
              </div>
              <Phone className="ml-auto h-5 w-5 opacity-80" />
            </div>
            <div className="bg-[#ECE5DD] p-4">
              <p className="mb-2 text-center text-[11px] font-medium text-[#14201A]/50">Aujourd’hui — message généré par la vitrine</p>
              <div className="ml-auto max-w-[92%] whitespace-pre-wrap rounded-2xl rounded-tr-sm bg-[#DCF8C6] p-3 text-[13px] leading-relaxed shadow-sm">
                {demoMessage}
                <span className="mt-1 block text-right text-[10px] text-black/40">09:41 ✓✓</span>
              </div>
              <div className="mt-3 max-w-[80%] rounded-2xl rounded-tl-sm bg-white p-3 text-[13px] shadow-sm">
                Merci Fatima ! C’est disponible. Le livreur part à 14 h, livraison Plateau : 500 FCFA. Je vous appelle avant de partir. 🙏
                <span className="mt-1 block text-right text-[10px] text-black/40">09:43</span>
              </div>
            </div>
            <div className="flex items-center gap-2 bg-[#F0F0F0] px-3 py-2.5">
              <span className="flex-1 rounded-full bg-white px-4 py-2 text-sm text-black/40">Message…</span>
              <span className="grid h-10 w-10 place-items-center rounded-full bg-[#128C4A] text-white"><MessageCircle className="h-5 w-5" /></span>
            </div>
          </div>
          <p className="mt-3 text-center text-xs text-[#14201A]/50">↑ Voilà exactement ce que reçoit le marchand. Zéro saisie manuelle pour la cliente.</p>
        </div>
      </section>

      {/* ── Comment ça marche ──────────────────────────────── */}
      <section className="bg-white py-14">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="text-center text-3xl font-black">Comment ça marche ?</h2>
          <p className="mx-auto mt-2 max-w-xl text-center text-[#14201A]/60">Trois étapes, aucun compte pour vos clientes, aucune commission sur vos ventes pour démarrer.</p>
          <div className="mt-10 grid gap-5 md:grid-cols-3">
            {[
              { icon: Store, step: "1 — Le marchand", title: "Créez votre vitrine", text: "Inscrivez-vous avec votre numéro, ajoutez vos produits (photo, prix en FCFA, stock) et obtenez votre lien unique : /boutique/votre-nom." },
              { icon: Share2, step: "2 — La cliente", title: "Partagez & commandez", text: "Partagez le lien sur WhatsApp, Facebook ou en statut. La cliente choisit, ajuste les quantités et indique son quartier à Niamey — sans créer de compte." },
              { icon: MessageCircle, step: "3 — La commande", title: "Recevez tout sur WhatsApp", text: "Un clic sur « Valider via WhatsApp » : vous recevez le récapitulatif complet. Vous confirmez, vous livrez, vous êtes payé à la livraison." },
            ].map((c) => (
              <article key={c.title} className="rounded-3xl bg-[#FDF6E9] p-6 ring-1 ring-black/5">
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#075E54] text-white"><c.icon className="h-6 w-6" /></span>
                <p className="mt-4 text-xs font-bold uppercase tracking-wide text-[#C2410C]">{c.step}</p>
                <h3 className="mt-1 text-xl font-bold">{c.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-[#14201A]/70">{c.text}</p>
              </article>
            ))}
          </div>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 rounded-3xl bg-[#075E54] px-6 py-5 text-white">
            <span className="inline-flex items-center gap-2 font-semibold"><ClipboardList className="h-5 w-5 text-[#25D366]" /> Commandes suivies dans votre tableau de bord</span>
            <span className="inline-flex items-center gap-2 font-semibold"><Truck className="h-5 w-5 text-[#25D366]" /> Quartiers de Niamey intégrés : {QUARTIERS.slice(0, 4).join(", ")}…</span>
            <span className="inline-flex items-center gap-2 font-semibold"><Link2 className="h-5 w-5 text-[#25D366]" /> Un seul lien à partager partout</span>
          </div>
        </div>
      </section>

      {/* ── Boutiques démo ─────────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-4 py-14">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="text-3xl font-black">Boutiques en ligne</h2>
            <p className="mt-1 text-[#14201A]/60">Essayez le parcours cliente complet, jusqu’à l’ouverture de WhatsApp.</p>
          </div>
          <Link href="/inscription" className="inline-flex items-center gap-1 font-bold text-[#128C4A]">Ouvrir la mienne <ArrowRight className="h-4 w-4" /></Link>
        </div>
        <div className="mt-6 grid gap-5 sm:grid-cols-2">
          {allStores.map((s) => (
            <Link key={s.id} href={`/boutique/${s.slug}`} className="group rounded-3xl bg-white p-5 shadow-sm ring-1 ring-black/5 transition hover:shadow-md">
              <div className="flex items-start gap-4">
                <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-2xl font-black text-white" style={{ background: s.accentColor }}>
                  {s.logoUrl && !s.logoUrl.startsWith("http") ? s.logoUrl : s.name.charAt(0)}
                </span>
                <div className="min-w-0">
                  <h3 className="truncate text-lg font-bold group-hover:text-[#128C4A]">{s.name}</h3>
                  <p className="line-clamp-2 text-sm text-[#14201A]/60">{s.description}</p>
                  <p className="mt-2 flex flex-wrap gap-2 text-xs font-semibold">
                    <span className="inline-flex items-center gap-1 rounded-full bg-[#FDF6E9] px-2.5 py-1"><Package className="h-3.5 w-3.5" /> {countByStore.get(s.id) || 0} produits</span>
                    <span className={`rounded-full px-2.5 py-1 ${s.isOpen ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-700"}`}>{s.isOpen ? "● Ouverte" : "● Fermée"}</span>
                    <span className="rounded-full bg-[#FDF6E9] px-2.5 py-1">📍 {s.neighborhood || s.city}</span>
                  </p>
                </div>
              </div>
              <p className="mt-4 inline-flex items-center gap-1 text-sm font-bold text-[#128C4A]">Visiter la vitrine <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" /></p>
            </Link>
          ))}
        </div>

        <div className="mt-10 rounded-3xl bg-[#14201A] p-6 text-white sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="text-2xl font-black">Compte marchand de démonstration</h3>
              <p className="mt-1 text-white/70">Connectez-vous pour gérer le catalogue de « Chez Awa », voir ses commandes et modifier la boutique.</p>
              <p className="mt-3 inline-block rounded-xl bg-white/10 px-4 py-2 font-mono text-sm">📱 +227 96 12 34 56 &nbsp;•&nbsp; 🔑 demo1234</p>
            </div>
            <Link href="/connexion" className="rounded-full bg-[#25D366] px-6 py-3 font-bold text-[#075E54]">Ouvrir le tableau de bord</Link>
          </div>
          <p className="mt-4 text-xs text-white/40">Astuce test : ouvrez la vitrine « Chez Awa », passez une commande, puis retrouvez-la dans le tableau de bord (statut : En attente → Confirmée → Livrée).</p>
        </div>
      </section>

      <footer className="border-t border-black/10 py-8 text-center text-sm text-[#14201A]/50">
        WhatsApp-Commerce Hub — MVP conçu pour les marchands du Niger 🇳🇪 • Prix en FCFA • {formatFCFA(0).replace("0 ", "")} accepté à la livraison
      </footer>
    </main>
  );
}
