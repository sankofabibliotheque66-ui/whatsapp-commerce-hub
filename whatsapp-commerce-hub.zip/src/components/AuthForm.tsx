"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Loader2, MessageCircle, Phone, Lock, Store, User } from "lucide-react";

const inputCls = "w-full rounded-xl border border-black/15 bg-white px-4 py-3 pl-11 outline-none focus:border-[#128C4A] focus:ring-2 focus:ring-[#25D366]/40";

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const [form, setForm] = useState({ phone: "", password: "", storeName: "", displayName: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const isRegister = mode === "register";

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setError(""); setLoading(true);
    try {
      const res = await fetch(`/api/auth/${isRegister ? "register" : "login"}`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Une erreur est survenue");
      router.push("/dashboard"); router.refresh();
    } catch (err) { setError(err instanceof Error ? err.message : "Erreur"); setLoading(false); }
  }

  return (
    <main className="grid min-h-screen place-items-center px-4 py-10">
      <div className="w-full max-w-md">
        <Link href="/" className="mb-6 flex items-center justify-center gap-2 font-black text-lg">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#075E54] text-white"><MessageCircle className="h-5 w-5" /></span>
          WhatsApp<span className="-ml-2 text-[#128C4A]">-Commerce</span> Hub
        </Link>
        <form onSubmit={submit} className="rounded-3xl bg-white p-6 shadow-lg ring-1 ring-black/5 sm:p-8">
          <h1 className="text-2xl font-black">{isRegister ? "Créez votre boutique" : "Bon retour !"}</h1>
          <p className="mt-1 text-sm text-[#14201A]/60">
            {isRegister ? "Inscription par numéro de téléphone. Votre vitrine est prête en 5 minutes." : "Connectez-vous avec votre numéro de téléphone."}
          </p>

          {error && <p className="mt-4 rounded-xl bg-red-50 px-4 py-3 text-sm font-medium text-red-700 ring-1 ring-red-200">{error}</p>}

          <div className="mt-5 space-y-3">
            {isRegister && (
              <>
                <label className="block">
                  <span className="mb-1 block text-sm font-semibold">Nom de votre boutique *</span>
                  <span className="relative block"><Store className="absolute left-3.5 top-3.5 h-5 w-5 text-black/30" />
                    <input required className={inputCls} placeholder="Ex. Chez Awa — Pagnes & Beauté" value={form.storeName} onChange={(e) => setForm({ ...form, storeName: e.target.value })} /></span>
                </label>
                <label className="block">
                  <span className="mb-1 block text-sm font-semibold">Votre nom (optionnel)</span>
                  <span className="relative block"><User className="absolute left-3.5 top-3.5 h-5 w-5 text-black/30" />
                    <input className={inputCls} placeholder="Ex. Awa Diallo" value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} /></span>
                </label>
              </>
            )}
            <label className="block">
              <span className="mb-1 block text-sm font-semibold">Numéro de téléphone *</span>
              <span className="relative block"><Phone className="absolute left-3.5 top-3.5 h-5 w-5 text-black/30" />
                <input required inputMode="tel" className={inputCls} placeholder="+227 96 12 34 56" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></span>
              <span className="mt-1 block text-xs text-[#14201A]/50">Ce numéro sert d’identifiant. Par défaut, c’est aussi votre WhatsApp boutique (modifiable ensuite).</span>
            </label>
            <label className="block">
              <span className="mb-1 block text-sm font-semibold">Mot de passe *</span>
              <span className="relative block"><Lock className="absolute left-3.5 top-3.5 h-5 w-5 text-black/30" />
                <input required type="password" minLength={6} className={inputCls} placeholder="6 caractères minimum" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></span>
            </label>
          </div>

          <button disabled={loading} className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-[#128C4A] py-3.5 font-bold text-white hover:bg-[#0F7A3E] disabled:opacity-60">
            {loading && <Loader2 className="h-5 w-5 animate-spin" />}
            {isRegister ? "Créer ma boutique gratuitement" : "Se connecter"}
          </button>

          {!isRegister && (
            <div className="mt-4 rounded-xl bg-[#FDF6E9] px-4 py-3 text-center text-sm">
              Compte démo : <strong>+227 96 12 34 56</strong> / <strong>demo1234</strong>
              <button type="button" className="mt-1 block w-full font-bold text-[#128C4A]" onClick={() => setForm({ ...form, phone: "+22796123456", password: "demo1234" })}>Remplir automatiquement</button>
            </div>
          )}

          <p className="mt-5 text-center text-sm text-[#14201A]/60">
            {isRegister ? <>Déjà marchand ? <Link href="/connexion" className="font-bold text-[#128C4A]">Se connecter</Link></>
              : <>Pas encore de boutique ? <Link href="/inscription" className="font-bold text-[#128C4A]">Créer un compte</Link></>}
          </p>
        </form>
      </div>
    </main>
  );
}
