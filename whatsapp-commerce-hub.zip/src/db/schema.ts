import {
  pgTable, uuid, text, integer, boolean, timestamp, jsonb,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/*  WhatsApp-Commerce Hub — schéma PostgreSQL (Drizzle ORM)            */
/*  merchants 1─1 stores 1─n products                                  */
/*  stores    1─n orders (commandes reçues via la vitrine)             */
/* ------------------------------------------------------------------ */

export const merchants = pgTable("merchants", {
  id: uuid("id").defaultRandom().primaryKey(),
  phone: text("phone").notNull().unique(), // ex. +22796123456 (identifiant de connexion)
  passwordHash: text("password_hash").notNull(),
  displayName: text("display_name").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const sessions = pgTable("sessions", {
  token: text("token").primaryKey(),
  merchantId: uuid("merchant_id").notNull().references(() => merchants.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const stores = pgTable("stores", {
  id: uuid("id").defaultRandom().primaryKey(),
  merchantId: uuid("merchant_id").notNull().unique().references(() => merchants.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(), // lien unique : /boutique/[slug]
  description: text("description").notNull().default(""),
  logoUrl: text("logo_url").notNull().default(""), // URL ou emoji
  whatsappNumber: text("whatsapp_number").notNull(), // format international sans "+" : 22796123456
  city: text("city").notNull().default("Niamey"),
  neighborhood: text("neighborhood").notNull().default(""), // quartier de la boutique
  accentColor: text("accent_color").notNull().default("#128C4A"),
  isOpen: boolean("is_open").notNull().default(true),
  deliveryInfo: text("delivery_info").notNull().default("Paiement à la livraison. Livraison à Niamey sous 24 h."),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const products = pgTable("products", {
  id: uuid("id").defaultRandom().primaryKey(),
  storeId: uuid("store_id").notNull().references(() => stores.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  price: integer("price").notNull(), // en FCFA, entier (pas de centimes)
  oldPrice: integer("old_price"), // prix barré optionnel
  imageUrl: text("image_url").notNull().default(""),
  category: text("category").notNull().default("Général"),
  stockStatus: text("stock_status").notNull().default("in_stock"), // in_stock | out_of_stock
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type OrderItem = {
  productId: string;
  name: string;
  unitPrice: number;
  quantity: number;
};

export const orders = pgTable("orders", {
  id: uuid("id").defaultRandom().primaryKey(),
  storeId: uuid("store_id").notNull().references(() => stores.id, { onDelete: "cascade" }),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  neighborhood: text("neighborhood").notNull(), // quartier à Niamey
  landmark: text("landmark").notNull().default(""), // point de repère précis
  note: text("note").notNull().default(""),
  items: jsonb("items").$type<OrderItem[]>().notNull(),
  total: integer("total").notNull(), // FCFA
  status: text("status").notNull().default("pending"), // pending | confirmed | delivered | cancelled
  channel: text("channel").notNull().default("whatsapp"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Merchant = typeof merchants.$inferSelect;
export type Store = typeof stores.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Order = typeof orders.$inferSelect;
