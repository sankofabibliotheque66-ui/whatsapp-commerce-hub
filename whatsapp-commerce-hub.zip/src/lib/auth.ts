import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { eq, gt, and } from "drizzle-orm";
import { db } from "@/db";
import { merchants, sessions, stores, type Merchant, type Store } from "@/db/schema";

const COOKIE = "wch_session";
const SESSION_DAYS = 30;

/* Hachage mot de passe : scrypt (natif Node, aucun package externe) */
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split(":");
    const candidate = scryptSync(password, salt, 64);
    return timingSafeEqual(candidate, Buffer.from(hash, "hex"));
  } catch { return false; }
}

/** Normalise un numéro : "+227 96 12 34 56" -> "+22796123456" */
export function normalizePhone(raw: string): string {
  const digits = (raw || "").replace(/\D/g, "").replace(/^00/, "");
  if (digits.length === 8) return `+227${digits}`; // défaut Niger
  return `+${digits}`;
}

/** "Chez Awa Niamey !" -> "chez-awa-niamey" (slug unique, complété si besoin) */
export function slugify(input: string): string {
  return input.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48) || "ma-boutique";
}

export async function createSession(merchantId: string) {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400_000);
  await db.insert(sessions).values({ token, merchantId, expiresAt });
  const jar = await cookies();
  jar.set(COOKIE, token, { httpOnly: true, sameSite: "lax", path: "/", expires: expiresAt });
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.token, token));
  jar.delete(COOKIE);
}

export async function getCurrentMerchant(): Promise<{ merchant: Merchant; store: Store } | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (!token) return null;
  const [session] = await db.select().from(sessions)
    .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date()))).limit(1);
  if (!session) return null;
  const [merchant] = await db.select().from(merchants).where(eq(merchants.id, session.merchantId)).limit(1);
  if (!merchant) return null;
  const [store] = await db.select().from(stores).where(eq(stores.merchantId, merchant.id)).limit(1);
  if (!store) return null;
  return { merchant, store };
}
