import { db } from "@/db";
import { merchants, stores, products, orders } from "@/db/schema";
import { hashPassword } from "@/lib/auth";

const img = (id: number) => `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=640`;

/** Données de démonstration (créées une seule fois, si la base est vide). */
export async function ensureSeed() {
  const existing = await db.select({ id: stores.id }).from(stores).limit(1);
  if (existing.length) return;

  const [awa] = await db.insert(merchants).values({
    phone: "+22796123456", passwordHash: hashPassword("demo1234"), displayName: "Awa Diallo",
  }).returning();
  const [storeA] = await db.insert(stores).values({
    merchantId: awa.id, name: "Chez Awa — Pagnes & Beauté", slug: "chez-awa-niamey",
    description: "Pagnes wax, foulards, cuir artisanal et beurre de karité pur, sélectionnés au Grand Marché de Niamey. Commandez ici, payez à la livraison.",
    whatsappNumber: "22796123456", city: "Niamey", neighborhood: "Grand Marché",
    accentColor: "#128C4A", deliveryInfo: "Paiement à la livraison (espèces ou Mobile Money). Livraison Niamey : 500–1 000 FCFA selon le quartier, offerte dès 20 000 FCFA.",
  }).returning();

  const [karim] = await db.insert(merchants).values({
    phone: "+22798765432", passwordHash: hashPassword("demo1234"), displayName: "Karim Souley",
  }).returning();
  const [storeB] = await db.insert(stores).values({
    merchantId: karim.id, name: "Niamey Délices — Terroir & Épices", slug: "niamey-delices",
    description: "Épices, bissap, miel et produits du terroir nigérien, conditionnés proprement et livrés partout à Niamey.",
    whatsappNumber: "22798765432", city: "Niamey", neighborhood: "Plateau",
    accentColor: "#C2410C", deliveryInfo: "Paiement à la livraison. Commandes avant 15 h livrées le jour même à Niamey.",
  }).returning();

  await db.insert(products).values([
    { storeId: storeA.id, name: "Pagne wax premium — 6 yards", description: "Wax 100 % coton, couleurs éclatantes qui ne déteignent pas. Idéal robe, boubou ou ensemble.", price: 8500, oldPrice: 10000, imageUrl: img(38528494), category: "Pagnes & tissus", stockStatus: "in_stock" },
    { storeId: storeA.id, name: "Foulard wax assorti (headwrap)", description: "Foulard prêt à nouer, assorti à nos pagnes. Plusieurs coloris disponibles sur WhatsApp.", price: 3500, imageUrl: img(38528500), category: "Pagnes & tissus", stockStatus: "in_stock" },
    { storeId: storeA.id, name: "Sac bandoulière en cuir artisanal", description: "Cuir véritable cousu main par les artisans de Niamey. Doublure intérieure + poche zippée.", price: 15000, oldPrice: 18000, imageUrl: img(27680730), category: "Maroquinerie", stockStatus: "in_stock" },
    { storeId: storeA.id, name: "Collier de perles artisanales", description: "Perles colorées montées à la main. Léger, solide, parfait pour les cérémonies.", price: 4500, imageUrl: img(1212048), category: "Bijoux", stockStatus: "in_stock" },
    { storeId: storeA.id, name: "Beurre de karité pur — 250 g", description: "Karité brut non raffiné du Niger. Peau, cheveux, massage. Pot hermétique de 250 g.", price: 2500, imageUrl: img(17596984), category: "Beauté", stockStatus: "in_stock" },
    { storeId: storeA.id, name: "Coffret soins naturels (3 produits)", description: "Beurre de karité, savon noir et huile naturelle. Le coffret cadeau parfait.", price: 7500, oldPrice: 9000, imageUrl: img(19522722), category: "Beauté", stockStatus: "in_stock" },
    { storeId: storeA.id, name: "Sandales femme en cuir", description: "Semelle confortable, cuir souple. Pointures 37 à 42 — précisez la pointure sur WhatsApp.", price: 9000, imageUrl: img(27204307), category: "Chaussures", stockStatus: "out_of_stock" },
    { storeId: storeA.id, name: "Huile parfumée naturelle — 100 ml", description: "Parfum doux et longue tenue, à base d'ingrédients naturels.", price: 4000, imageUrl: img(17596986), category: "Beauté", stockStatus: "in_stock" },

    { storeId: storeB.id, name: "Mélange d'épices maison — 200 g", description: "Épices sélectionnées et moulues à Niamey : pour grillades, sauces et soupes.", price: 2000, imageUrl: img(7829483), category: "Épices", stockStatus: "in_stock" },
    { storeId: storeB.id, name: "Piment rouge séché — 500 g", description: "Piment fort séché au soleil, trié et propre. Pour les amateurs de sensations.", price: 3000, oldPrice: 3500, imageUrl: img(38882159), category: "Épices", stockStatus: "in_stock" },
    { storeId: storeB.id, name: "Herbes aromatiques séchées — 100 g", description: "Herbes séchées naturellement, parfum intense pour thés et cuisines.", price: 1500, imageUrl: img(35156983), category: "Épices", stockStatus: "in_stock" },
    { storeId: storeB.id, name: "Assortiment terroir à offrir", description: "Coffret découverte : épices, herbes et condiments du Niger, prêt à offrir.", price: 6500, imageUrl: img(31188635), category: "Coffrets", stockStatus: "in_stock" },
  ]);

  const prodsA = await db.select().from(products);
  const byName = (n: string) => prodsA.find((p) => p.name.startsWith(n))!;
  const now = Date.now();
  const mk = (storeId: string, name: string, phone: string, q: string, rep: string, items: { productId: string; name: string; unitPrice: number; quantity: number }[], status: string, hoursAgo: number) => ({
    storeId, customerName: name, customerPhone: phone, neighborhood: q, landmark: rep,
    items, total: items.reduce((s, i) => s + i.unitPrice * i.quantity, 0), status,
    createdAt: new Date(now - hoursAgo * 3600_000),
  });
  await db.insert(orders).values([
    mk(storeA.id, "Fatima Moussa", "98 11 22 33", "Plateau", "À côté de la pharmacie du Plateau", [
      { productId: byName("Pagne wax").id, name: "Pagne wax premium — 6 yards", unitPrice: 8500, quantity: 2 },
      { productId: byName("Beurre de karité").id, name: "Beurre de karité pur — 250 g", unitPrice: 2500, quantity: 1 },
    ], "pending", 2),
    mk(storeA.id, "Aïcha Ibrahim", "96 55 44 33", "Yantala", "En face de l'école Yantala", [
      { productId: byName("Coffret soins").id, name: "Coffret soins naturels (3 produits)", unitPrice: 7500, quantity: 1 },
    ], "confirmed", 9),
    mk(storeA.id, "Mariam Abdou", "97 88 99 00", "Koira Kano", "Près du marché Koira Kano", [
      { productId: byName("Sac bandoulière").id, name: "Sac bandoulière en cuir artisanal", unitPrice: 15000, quantity: 1 },
      { productId: byName("Collier").id, name: "Collier de perles artisanales", unitPrice: 4500, quantity: 2 },
    ], "delivered", 30),
    mk(storeB.id, "Oumarou Seyni", "99 00 11 22", "Bobiel", "Derrière la mosquée de Bobiel", [
      { productId: byName("Mélange d'épices").id, name: "Mélange d'épices maison — 200 g", unitPrice: 2000, quantity: 3 },
    ], "pending", 5),
  ]);
}
