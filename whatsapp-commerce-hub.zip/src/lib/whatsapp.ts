/* ============================================================================
 *  src/lib/whatsapp.ts — Générateur de lien WhatsApp (cœur du MVP)
 * ----------------------------------------------------------------------------
 *  Principe : aucun panier e-commerce lourd, aucun paiement par carte.
 *  La vitrine construit un message texte structuré, l'encode en UTF-8
 *  (encodeURIComponent) et ouvre https://wa.me/<numero>?text=<message>.
 *  Le marchand reçoit la commande dans SON WhatsApp habituel et confirme
 *  en répondant au message. Paiement à la livraison / Mobile Money ensuite.
 * ========================================================================== */

export type WhatsAppCartItem = {
  name: string;
  unitPrice: number; // FCFA
  quantity: number;
};

export type WhatsAppCustomer = {
  name: string;
  phone: string;
  neighborhood: string; // Quartier (Niamey)
  landmark?: string; // Point de repère précis
  note?: string;
};

/** Formate un montant FCFA : 12500 -> "12 500 FCFA" (espaces insécables fines) */
export function formatFCFA(amount: number): string {
  return `${Math.round(amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ")} FCFA`;
}

/** Normalise un numéro vers le format wa.me : chiffres uniquement, indicatif pays inclus.
 *  "+227 96 12 34 56" -> "22796123456" ; "96 12 34 56" (Niger par défaut) -> "22796123456" */
export function normalizeWhatsAppNumber(raw: string, defaultCountry = "227"): string {
  const digits = (raw || "").replace(/\D/g, "").replace(/^00/, "");
  if (!digits) return "";
  if (digits.length <= 8) return `${defaultCountry}${digits}`; // numéro local nigérien (8 chiffres)
  return digits;
}

/**
 * Construit le message pré-formaté envoyé au marchand.
 * Les *astérisques* sont le gras WhatsApp, les — et • structurent la lecture
 * sur mobile, même avec une connexion faible (texte pur, ~0 Ko).
 */
export function buildWhatsAppMessage(params: {
  storeName: string;
  items: WhatsAppCartItem[];
  customer: WhatsAppCustomer;
  orderRef?: string;
}): string {
  const { storeName, items, customer, orderRef } = params;
  const total = items.reduce((sum, i) => sum + i.unitPrice * i.quantity, 0);
  const lines: string[] = [];

  lines.push(`*Nouvelle commande — ${storeName}*`);
  if (orderRef) lines.push(`Réf : ${orderRef}`);
  lines.push("");
  lines.push("*Articles :*");
  items.forEach((item, idx) => {
    lines.push(`${idx + 1}. ${item.name}`);
    lines.push(`   ${item.quantity} x ${formatFCFA(item.unitPrice)} = *${formatFCFA(item.unitPrice * item.quantity)}*`);
  });
  lines.push("");
  lines.push(`*Total : ${formatFCFA(total)}*`);
  lines.push("(Paiement à la livraison)");
  lines.push("");
  lines.push("*Livraison :*");
  lines.push(`Nom : ${customer.name}`);
  lines.push(`Téléphone : ${customer.phone}`);
  lines.push(`Quartier : ${customer.neighborhood}`);
  if (customer.landmark?.trim()) lines.push(`Point de repère : ${customer.landmark.trim()}`);
  if (customer.note?.trim()) lines.push(`Note : ${customer.note.trim()}`);
  lines.push("");
  lines.push("Merci de me confirmer la disponibilité et le délai de livraison.");

  return lines.join("\n");
}

/**
 * LA fonction demandée : génère et (optionnellement) déclenche le lien wa.me.
 *
 * @example
 *   const url = buildWhatsAppOrderLink({
 *     merchantWhatsApp: "+227 96 12 34 56",
 *     storeName: "Chez Awa — Pagnes & Cosmétiques",
 *     items: [{ name: "Pagne wax 6 yards", unitPrice: 8500, quantity: 2 }],
 *     customer: { name: "Fatima", phone: "98 77 66 55", neighborhood: "Plateau" },
 *   });
 *   window.open(url, "_blank"); // ou openWhatsAppOrder({...}) directement
 */
export function buildWhatsAppOrderLink(params: {
  merchantWhatsApp: string;
  storeName: string;
  items: WhatsAppCartItem[];
  customer: WhatsAppCustomer;
  orderRef?: string;
}): string {
  const number = normalizeWhatsAppNumber(params.merchantWhatsApp);
  const message = buildWhatsAppMessage(params);
  // encodeURIComponent garantit l'UTF-8 (accents, FCFA, retours ligne %0A…)
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}

/** Variante "1 clic" : construit le lien et ouvre WhatsApp (web ou application). */
export function openWhatsAppOrder(params: Parameters<typeof buildWhatsAppOrderLink>[0]): string {
  const url = buildWhatsAppOrderLink(params);
  if (typeof window !== "undefined") window.open(url, "_blank", "noopener,noreferrer");
  return url;
}
